import React from 'react'

import Question from '../components/Question/Question'


export default function Home() {

	return (
		<>
			<Question />
		</>
	)
}
